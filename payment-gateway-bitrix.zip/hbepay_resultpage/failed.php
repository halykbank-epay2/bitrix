<?php

require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");

?>

	<h2>Payment error</h2>

	<p class="text-justify" align="justify">
		The payment system returned an error during the payment on the order. Back to <a href="/">home page</a> or <a href="/personal/">go to your personal account</a>.
	</p>


<?php

require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");
