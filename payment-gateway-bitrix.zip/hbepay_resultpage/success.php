<?php

require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");

?>

	<h2>Payment successfully accepted</h2>

	<p class="text-justify" align="justify">
		Your payment has been successfully accepted.The order status will be changed soon. Back to <a href="/">home page</a> or <a href="/personal/">go to your personal account</a>.
	</p>


<?php

require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");
